from threading import Thread
wep = [1,2,3,4,5,6]# 1 is a sword, 2 is a Rifle, and 3 is Revolver 4 is stabby dagger , 5 is teeth 6 is throwy dagger(with 4 points)
cenem = {
  1:[1,5,]
}
"""
There is some syntax to cenem, and here is the syntax:
<enemy#>:[<enemhp>,<enemspeed>,<timestampOfSpawn]

the enemy number is growing based on how many enemies there are on the field at any one time. once the enemy dies, the entry is deleted.


The enemHp and enemspeed is based of off the list and is made depending on the random values that it comes up with.

TimeStamp of Spawn is still in progress.
"""
enemHp = [1,2,3]#1 is relatively weak, 2 is medium, and 3 is High Health
enemSpeed = [1,2,3]#1 is slow, 2 is joggin pace, and 3 is sprinting
# how far the player can see (% of 1)
visiblity = float(.25)

while True:

  uput = input("")
  if uput == "look":
    #Look function call
    print(123)

