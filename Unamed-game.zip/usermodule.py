import threading
wep = range(1,5)# 1 is a sword, 2 is a Rifle, and 3 is Revolver 4 is stabby dagger , 5 is teeth 6 is throwy dagger(with 4 points)
